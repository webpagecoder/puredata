'use strict';

import { DateParser, HumanParseOptions, HumanPrecision, IsoOrdinalParseOptions, IsoOrdinalPrecision, IsoParseOptions, IsoPrecision, IsoWeekParseOptions, IsoWeekPrecision } from '../date/DateParser.ts';
import { DatePart, DatePartIso, DatePartPresence } from '../date/DatePart.ts';
import { DateType } from '../date/DateType.ts';
import { DateHandler } from '../handlers/DateHandler.ts';
import { Locale } from '../Locale.ts';
import { Presence } from '../Presence.ts';
import { Chain, ChainProps } from './Chain.ts';

type OutputFormat = [
    type: DateType,
    precision: HumanPrecision | IsoPrecision | IsoOrdinalPrecision | IsoWeekPrecision
] | string | null;

type DateOrder = 'MDY' | 'DMY' | 'YMD';

export type DateChainProps = ChainProps<typeof DateHandler> & {
    dateOrder?: DateOrder;
    dateParser?: DateParser;
    outputFormat?: OutputFormat;
    utcOffset?: [number, number];
};

class DateChain extends Chain<DateChainProps> {
    protected _dateParser: DateParser;
    protected _outputFormat: OutputFormat;
    protected _utcOffset: [number, number];

    constructor(props: DateChainProps) {
        super(props);

        const {
            dateOrder = 'MDY',
            dateParser = new DateParser(this._locale, dateOrder),
            outputFormat = null,
            utcOffset = [0, 0]
        } = props;

        this._dateParser = dateParser;
        this._outputFormat = outputFormat;
        this._utcOffset = utcOffset;
    }

    public override clone(props: Partial<DateChainProps> = {}): this {
        const clone = super.clone(props);
        const {
            dateOrder,
            dateParser = this._dateParser,
            outputFormat = this._outputFormat,
            utcOffset = this._utcOffset
        } = props;

        clone._dateParser = dateOrder
            ? new DateParser(this._locale, dateOrder)
            : dateParser;
        clone._dateParser = dateParser;
        clone._outputFormat = outputFormat;
        clone._utcOffset = utcOffset;
        return clone;
    }

    public assertEmptyPipelineAndSkipPreprocess(dateSubType: string): void {
        if (this._pipeline.length > 0) {
            throw new Error(dateSubType + '() processor must be the first processor in the chain, if used.');
        }
    }

    // Configurators

    /**
     * Configure whether to automatically convert string values to numbers
     * @param {boolean} autoConvert - Whether to enable automatic conversion
     * @returns {NumberChain} The chain instance for method chaining
     */
    public configDateOrder(dateOrder: DateOrder): this {
        return this.clone({ dateOrder });
    }

    // Validators

    /**
     * Validates and parses human-readable date formats.
     * Must be the first processor in the chain if used.
     * @param {Object} [options={}] - Parsing options
     * @param {string[]} [options.required] - Required date components
     * @param {string[]} [options.forbidden] - Forbidden date components
     * @param {'MDY' | 'DMY' | 'YMD'} [options.dateOrder] - The order of date components
     * @returns {DateChain} Returns the chain for method chaining
     * @example
     * date.human() // Accepts "Jan 1, 2023", "1/1/2023", etc.
     */
    human(options: HumanParseOptions = {}) {
        this.assertEmptyPipelineAndSkipPreprocess('human');
        return this.addStep('human', [this._dateParser, options]);
    }

    /**
     * Validates and parses ISO 8601 date formats.
     * Must be the first processor in the chain if used.
     * @param {Object} [options={}] - Parsing options
     * @param {string[]} [options.required] - Required date components
     * @param {string[]} [options.forbidden] - Forbidden date components
     * @param {boolean} [options.allowBasic] - Allow basic format (without hyphens)
     * @returns {DateChain} Returns the chain for method chaining
     * @example
     * date.iso() // Accepts "2023-01-01", "2023-01-01T12:00:00Z", etc.
     */
    public iso(options: IsoParseOptions = {}) {
        this.assertEmptyPipelineAndSkipPreprocess('iso');
        return this.addStep('iso', [this._dateParser, options]);
    }

    /**
     * Validates and parses ISO 8601 ordinal date formats (YYYY-DDD).
     * Must be the first processor in the chain if used.
     * @param {Object} [options={}] - Parsing options
     * @param {boolean} [options.allowBasic] - Allow basic format (without hyphens)
     * @returns {DateChain} Returns the chain for method chaining
     * @example
     * date.isoOrdinal() // Accepts "2023-001", "2023-365", etc.
     */
    public isoOrdinal(options = {}) {
        this.assertEmptyPipelineAndSkipPreprocess('isoOrdinal');
        return this.addStep('isoOrdinal', [this._dateParser, options]);
    }

    /**
     * Validates and parses ISO 8601 week date formats (YYYY-Www-D).
     * Must be the first processor in the chain if used.
     * @param {Object} [options={}] - Parsing options
     * @param {boolean} [options.allowBasic] - Allow basic format (without hyphens)
     * @returns {DateChain} Returns the chain for method chaining
     * @example
     * date.isoWeek() // Accepts "2023-W01-1", "2023-W52-7", etc.
     */
    public isoWeek(options = {}) {
        this.assertEmptyPipelineAndSkipPreprocess('isoWeek');
        return this.addStep('isoWeek', [this._dateParser, options]);
    }

    /**
     * Validates and parses timestamp formats.
     * Must be the first processor in the chain if used.
     * @param {boolean} [isMilliseconds] - Whether to expect JavaScript timestamps (milliseconds)
     * @returns {DateChain} Returns the chain for method chaining
     * @example
     * date.timestamp() // Accepts JavaScript timestamps in milliseconds
     * date.timestamp(false) // Accepts Unix timestamps in seconds
     */
    public timestamp(isMilliseconds: boolean = true) {
        this.assertEmptyPipelineAndSkipPreprocess('timestamp');
        return this.addStep('timestamp', [isMilliseconds]);
    }

    /**
     * Validates that the date represents today.
     * @returns {DateChain} Returns the chain for method chaining
     * @example
     * date.today() // Must be today's date
     */
    public today() {
        const now = new Date();
        let [hours, minutes] = this._utcOffset;
        now.setUTCHours(now.getUTCHours() + hours);
        now.setUTCMinutes(now.getUTCMinutes() + minutes);
        return this.addStep('today', [now]);
    }

    // Transformers


    // Exporters
    public format(formatString: string) {
        return this.clone({
            outputType: 'custom',
            outputFormat: formatString
        });
    }

    public toDateObj() {
        return this.clone({ outputType: 'object' });
    }

    /**
     * Configures the output to be in ISO 8601 format.
     * @returns {DateChain} Returns the chain for method chaining
     * @example
     * date.toIso() // Output: "2023-01-01T12:00:00.000Z"
     */
    toIso(precision: IsoPrecision = 'timezone') {
        return this.clone({
            outputType: 'iso',
            outputFormat: precision
        });
    }

    /**
     * Configures the output to be in ISO 8601 ordinal date format.
     * @returns {DateChain} Returns the chain for method chaining
     * @example
     * date.toIsoOrdinal() // Output: "2023-001" (first day of year)
     */
    public toIsoOrdinal() {
        return this.clone({ outputType: 'isoOrdinal' });
    }

    /**
     * Configures the output to be in ISO 8601 week date format.
     * @returns {DateChain} Returns the chain for method chaining
     * @example
     * date.toIsoWeek() // Output: "2023-W01-1" (first Monday of year)
     */
    public toIsoWeek() {
        return this.clone({ outputType: 'isoWeek' });
    }

    /**
     * Configures the output to be a timestamp (milliseconds since epoch).
     * @returns {DateChain} Returns the chain for method chaining
     * @example
     * date.toTimestamp() // Output: 1672531200000 (JavaScript timestamp)
     */
    public toTimestamp() {
        return this.clone({ outputType: 'timestamp' });
    }
}

export { DateChain };