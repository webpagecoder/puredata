'use strict';

import { Utils } from '../utils/Utils.ts';
import { ChainProcessor } from './ChainProcessor.ts';

class ObjectProcessor extends ChainProcessor {


    preProcess(tracker) {
        
        if (!Utils.isObject(tracker.getValue())) {
            return tracker.addError('object/base');
        }

        const { ensurePlain, cloneObject, maxDepth, maxKeyCount } = this.props.field.props;

        if (ensurePlain && !Utils.isPlainObject(tracker.getValue())) {
            return tracker.addError('object/plain');
        }

        if (maxDepth != null || maxKeyCount != null) {
            const result = Utils.getDepthAndKeyCount(tracker.getValue(), {
                maxDepth,
                maxKeyCount
            });
            if (result === false) {
                return tracker.addError('object/tooComplex', { maxDepth, maxKeyCount });
            }
        }

        if (cloneObject) {
            // Clone object if transforms are to be performed
            tracker.setValue(Utils.clone(tracker.getValue()));
        }
    }

}

export { ObjectProcessor };