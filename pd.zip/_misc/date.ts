'use strict';

// import { DEFAULT_LANGUAGE } from "../lib/config/DefaultLanguage.ts";
import { pd } from '../lib/pd.ts';
import { NormalizedDate } from "../lib/date/NormalizedDate.ts";
import {DateParser} from "../lib/date/DateParser.ts";

// const bd = new DateParser(pd.locale).parseHuman('sun. 2/27/2020 03:59:28 UTC');

const bd = new DateParser(pd.locale).parseTimestamp('1812151523223');
console.log(bd);


// const bd = new DateParser(pd.locale).parseIsoOrdinal('2020-001T03:59:28.888-01:22');
// console.log(bd);


// const bd = new DateParser(pd.locale).parseIsoWeek('2020-W01-7T03:59:28.888-01:22');
// console.log(bd);