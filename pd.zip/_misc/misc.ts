'use strict';

import { DatePart } from '../lib/date/DatePart.ts';
import { pd } from '../lib/pd.ts';
import { IsoParseOptions, IsoPrecision, HumanPrecision } from '../lib/date/DateParser.ts';
// import { type IsoPrecision } from '../lib/date/DateParser.ts';
// import { IsoPrecision } from '../lib/date/DateParser.ts';
// import { type Presence} from '../lib/Presence.ts';
// import { ObjectHandler } from '../lib/handlers/ObjectHandler.ts';
// import { Path } from '../lib/Path.ts';
// import { BooleanChain } from '../lib/fields/BooleanChain.ts';


const schema = pd.schema({
    a: pd.date().human().format('MM/DD/YYYY hh:mm A HH:mm Z ZZ').optional()

});
const result = schema.process({
    a: 'December 31, 2019 11:59pm -01:00'
})



console.log(result.value)
// console.log(2)
console.dir(result.errors, { depth: 8 })
// const ac = pd.array.exactly([1, 2,pd.number.isGreaterThan(10), pd.number]);
// const ac2 = pd.array().only([5,ac]);
// const ac3 = pd.array().setLabel("COOLNESS").tuple([1, 2, ac2]);
//  result = ac.filter([411,72, 4, 1, 2, 2]);
// console.log(result.getErrors());
//  result = ac2.filter([411, 4, 1, 3,2, 2, 'a']);
// console.log(result);
//  result = ac3.filter([1,2,[5,[1,2,33,4,2,1]]]);
// console.dir(result.getErrors(), {depth:4});


// pd.errors({
//     '///number/lessThan/': 'aaaa {comparison}',
// });









// REF

// const filter = pd.schema({
//     a: pd.number(),
//     b1: pd.schema({
//         c: pd.number(),
//         d: pd.value('../a'),
//         e: pd.pointer('/a')
//     }),
//     b2: pd.schema({
//         b3: pd.schema({
//             b4: pd.pointer('/')
//         })
//     })
// });



// const r = filter.process({
//     a: 55,
//     b: {
//         c: 33,
//         e:101
//     }
// })

// console.log(r.value);
// console.dir(r.getErrors(), { depth: 8 })






// // START

// const person = pd.schema({
//     a: pd.number().lessThan(10),
//     b: pd.number().lessThan(10),
//     c: pd.schema({
//         d: pd.number().lessThan(10),
//         e: pd.number().lessThan(10),
//         f: pd.schema({
//             g: pd.number().lessThan(10),
//             h: pd.number().lessThan(10),
//         }).label('inner2'),
//     }).label('inner').keyCount(32),
// }).default({ poop: true }).label('outer');

// const r = person.process({
//     a: 23233223,
//     c: {
//         // f: {

//         // }
//     }
// })

// console.log(r.value);
// // console.log(person.description);
// document.body.innerHTML = (r.formatErrors())


// // END




// START

// const person = pd.schema({
//     name: pd.string(),
//     age: pd.number(),
//     yearsToSS: pd.value('age', x => 65 - x),
//     property: pd.schema({
//         pet: pd.schema({
//             name: pd.string(),
//             prevPetName: pd.value('../name'),
//             nextPet: pd.pointer('/property/pet',0,1)
//         })
//     })
// }).default({ poop: true });

// const r = person.process({
//     name: 'john',
//     age: 44,
//     property: {
//         pet: {
//             name: 'Kelly',
//             prevPetName: 'yo',
//             nextPet: {
//                 name: 'Buddy',
//                 nextPet: {
//                     name: 'Rusty',
//                     prevPetName: 'rrrr'
//                 }
//             }
//         }
//     }
// })

// console.dir(r.value, {depth:5});
// console.dir(r.getErrors(), { depth: 8 })


// END











// START

// const person = pd.schema({
//     a: pd.schema({
//         b: pd.pointer('/a', 0, 1),
//         c: pd.pointer('/', 0, 2)
//     })
// }).default({ poop: true });

// const r = person.process({
//     a: {
//         // Level 1 of recursion
//         b: {  // This is '/a' reference - b depth level 1
//             // Level 2 of recursion (max depth for b)
//             b: {  // This is '/a' reference - b depth level 2 (max)
//                 b: undefined,  // b depth level 3 would exceed max for b
//                 c: {           // c depth level 1 (c has its own depth limit)
//                     a: {       // c can reference root twice
//                         b: undefined,  // b would start fresh but we're at c's level 1
//                         c: {           // c depth level 2 (max for c)
//                             a: undefined  // c depth level 3 would exceed max for c
//                         }
//                     }
//                 }
//             },
//             c: {  // This is '/' reference - c depth level 1
//                 a: {  // Back to root level structure
//                     b: {  // b depth level 1 (b starts fresh here)
//                         b: {  // b depth level 2 (max for b)
//                             b: undefined,
//                             c: undefined
//                         },
//                         c: undefined  // c depth level 1, but we'll keep it simple
//                     },
//                     c: {  // c depth level 2 (max for c)
//                         a: undefined  // c depth level 3 would exceed max for c
//                     }
//                 }
//             }
//         },
//         c: {  // This is '/' reference - c depth level 1
//             a: {  // Back to root level structure - c depth level 1
//                 b: {  // b depth level 1 (b starts fresh)
//                     b: {  // b depth level 2 (max for b)
//                         b: undefined,
//                         c: undefined
//                     },
//                     c: undefined
//                 },
//                 c: {  // c depth level 2 (max for c)
//                     a: undefined  // c depth level 3 would exceed max for c
//                 }
//             }
//         }
//     }
// })

// // console.dir(r.value, { depth: 5 });
// console.dir(r.getErrors(), { depth: 8 })


// END
















// UNCOMMENT BELOW





// const person2 = pd.schema({


//     // val2: pd.any().default(1),
//     val3: pd.number(),
//     val: pd.schema({
//         val3: pd.number(),
//         // // test: pd.schema({
//         // //     bla:pd.any()
//         // // })
//         // valInner: pd.satisfies('../val3', pd.schema({
//         //     valA: pd.number().greaterThan(50),
//         //     valB: pd.string().startsWith('H'),
//         //     valC: pd.satisfies('valB', pd.string().startsWith('H'))
//         //         .then(pd.number().lessThan(50))
//         //         .otherwise(pd.number().greaterThan(50))
//         // }))
//         //     // .or(pd.satisfies('val2', pd.number().lessThan(2)))
//         //     .then(989898)
//         //     .otherwise(111)
//     }),
//     val5: pd.string().lengthBetween(1,10).startsWith('o'),
//     // val4: pd.satisfies('.', pd.number().greaterThan(10)).then(777).otherwise(666)
// });

// // console.log('\n'+person2.describe());
// // // console.dir(person, {depth:4})

// let pr = person2.process({
//     // age: 10,
//     // a: 9,
//     // val: 5,
//     val: {
//         val3: 33,
//     },
//     val5: 'o121221',
//     // val2: 88,
//     val3: 33
// })


// console.log(person2.getDescription())

// const raw = pr.processErrorLanguage();
// const str = pr.getErrors();
// console.dir(pr.getErrors(), {depth:11});
// console.log(pr.value)

// // const w = pr.getChild('/more/');
// // console.log(pr.value)
// console.dir(pr.getErrors(), { depth: 11 });

// console.dir(Field.registry, {depth:2})
// console.log(w.value)

// // w.value = {
// //     uu:111,
// //     p:{},
// //     a:2222
// // };

// // console.log(pr.value);
// // console.log(w.value);


// // // const t = pd.string().optional();
// // // console.log(t.process().getErrors())






// console.log(Field.registry.size);










// // tracker testingbelow

// // const tracker = new ValueNode();
// // // const a = tracker.create('poop1', { a: 1, b: 2 });
// // const b = tracker.create('poop2', { a: 1, poop3: { c:3,d:4} });
// // // const c = b.create('poop3', { a: 11, b: 22 });

// // // console.dir(tracker, { depth: 10 });
// // console.log(tracker.getValue());
// // console.log(tracker.getValueByPath('poop2/a/'));
// // // tracker.setValue({ hello: 'world' });
// // console.dir(tracker.getValue(), { depth: 10 });


// // const child = tracker.getByPath('poop2/poop4/poop5');